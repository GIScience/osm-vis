module.exports = function _identity(x) { return x; };
