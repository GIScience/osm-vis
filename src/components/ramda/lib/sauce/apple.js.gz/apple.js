module.exports = [
  {
    browserName: 'safari',
    version: '5',
    platform: 'OS X 10.6'
  },
  {
    browserName: 'safari',
    version: '6',
    platform: 'OS X 10.8'
  },
  {
    browserName: 'safari',
    version: '7',
    platform: 'OS X 10.9'
  },
  {
    browserName: 'safari',
    version: '8',
    platform: 'OS X 10.10'
  }
];
