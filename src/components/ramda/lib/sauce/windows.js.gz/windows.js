module.exports = [
  {
    browserName: 'internet explorer',
    version: '11',
    platform: 'Windows 8.1'
  },
  {
    browserName: 'internet explorer',
    version: '10',
    platform: 'Windows 8'
  },
  {
    browserName: 'internet explorer',
    version: '9',
    platform: 'Windows 7'
  },
  {
    browserName: 'internet explorer',
    version: '8',
    platform: 'Windows 7'
  },
  {
    browserName: 'internet explorer',
    version: '7',
    platform: 'XP'
  },
  {
    browserName: 'chrome',
    version: '38',
    platform: 'Windows 8.1'
  },
  {
    browserName: 'firefox',
    version: '33',
    platform: 'Windows 8.1'
  }
];
