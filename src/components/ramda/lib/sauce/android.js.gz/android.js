module.exports = [
  {
    browserName: 'android',
    version: '4.4',
    deviceName: 'Android',
    'device-orientation': 'portrait',
    platform: 'Linux'
  },
  {
    browserName: 'android',
    version: '4.3',
    deviceName: 'Android',
    'device-orientation': 'portrait',
    platform: 'Linux'
  },
  {
    browserName: 'android',
    version: '4.2',
    deviceName: 'Android',
    'device-orientation': 'portrait',
    platform: 'Linux'
  },
  {
    browserName: 'android',
    version: '4.1',
    deviceName: 'Android',
    'device-orientation': 'portrait',
    platform: 'Linux'
  },
  {
    browserName: 'android',
    version: '4.0',
    deviceName: 'Android',
    'device-orientation': 'portrait',
    platform: 'Linux'
  }
];
