module.exports = {
  server: {
    options: {
      hostname: 'localhost',
      port: 3210,
      base: '.'
    }
  }
};
